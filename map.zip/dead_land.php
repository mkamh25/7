<?php
$level_limit = 2;
$header = "Selamat datang di wilayah kejahatan.";
?>                  
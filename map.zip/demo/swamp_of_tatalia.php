<?php
$level_limit = 1;
if (($user['class'] == "beastmaster") or ($user['class'] == "witch")) {
$header = "Selamat datang di tanah kelahiranmu.<br/><a href=\"index.php?action=castle&amp;pilis=$j&amp;id=$id\">Castle</a>";
}
else{
$header = "Selamat datang di kerajaan Tatalia.<br/><a href=\"index.php?action=castle&amp;pilis=$j&amp;id=$id\">Castle</a>";}
?>

<?php
$level_limit = 1;
if (($user['class'] == "knight") or ($user['class'] == "cleric")) {
$header = "Selamat datang pejuang di tanah kebanggaan mu.<br/><a href=\"index.php?action=castle&amp;pilis=city_of_erathia&amp;id=$id\">Castle</a>";
}
else{
$header = "Selamat datang di kerajaan Erathia.<br/><a href=\"index.php?action=castle&amp;pilis=city_of_erathia&amp;id=$id\">Castle</a>";
}
?>

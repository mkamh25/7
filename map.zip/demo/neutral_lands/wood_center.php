<?php
$level_limit = 5;

$obj[0] = "titus_the_scout";
$obj[1] = "rider_hole";

$unit[0] = "griffin";
$q_min[0] = 5;
$q_max[0] = 25;
$exp_min[0] = 2850;
$exp_max[0] = 4000;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "boar_rider";
$q_min[1] = 10;
$q_max[1] = 25;
$exp_min[1] = 2000;
$exp_max[1] = 5000;
$u_gold_min[1] = 8;
$u_gold_max[1] = 15;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="griffin";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=20;

$army[1]="boar_rider";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=15;

$gold_min = 4;
$gold_max = 8;
$gold_get = "5";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

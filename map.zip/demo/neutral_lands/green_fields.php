<?php
$level_limit = 1;

$unit[0] = "rogue";
$q_min[0] = 10;
$q_max[0] = 20;
$exp_min[0] = 1450;
$exp_max[0] = 2500;
$u_gold_min[0] = 5;
$u_gold_max[0] = 10;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "peasant";
$q_min[1] = 135;
$q_max[1] = 220;
$exp_min[1] = 1450;
$exp_max[1] = 2500;
$u_gold_min[1] = 5;
$u_gold_max[1] = 10;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$gold_min = 1;
$gold_max = 3;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

<?php
$level_limit = 20;


$unit[0] = "grim";
$q_min[0] = 20;
$q_max[0] = 30;
$exp_min[0] = 9500;
$exp_max[0] = 16000;
$u_gold_min[0] = 1;
$u_gold_max[0] = 1;
$u_gold_get[0] = 1;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "pendant_of_dispassion";
$u_artifact_get[0] = 500;

$unit[1] = "royal_griffin";
$q_min[1] = 44;
$q_max[1] = 90;
$exp_min[1] = 7999;
$exp_max[1] = 12999;
$u_gold_min[1] = 5;
$u_gold_max[1] = 10;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "magica_potion";
$u_artifact_get[1] = 200;

$gold_min = 20;
$gold_max = 25;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

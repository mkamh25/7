<?php
$level_limit = 15;
$obj[0] = "crystals_market";

$unit[0] = "iron_golem";
$q_min[0] = 20;
$q_max[0] = 45;
$exp_min[0] = 8580;
$exp_max[0] = 16580;
$u_gold_min[0] = 200;
$u_gold_max[0] = 300;
$u_gold_get[0] = 5;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "champions_milk";
$u_artifact_get[0] = 200;

$unit[1] = "troll";
$q_min[1] = 100;
$q_max[1] = 125;
$exp_min[1] = 7450;
$exp_max[1] = 14000;
$u_gold_min[1] = 100;
$u_gold_max[1] = 200;
$u_gold_get[1] = 5;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "magica_potion";
$u_artifact_get[1] = 200;

$army[0]="";
$armi_min[0]=0;
$armi_max[0]=0;
$army_get[0]=39999999990;

$army[1]="";
$armi_min[1]=0;
$armi_max[1]=0;
$army_get[1]=99999999999;

$gold_min = 10;
$gold_max = 90;
$gold_get = "6";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 9999999999;
?>

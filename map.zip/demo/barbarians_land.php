<?php
$level_limit = 1;
if (($user['class'] == "barbarian") or ($user['class'] == "battle_mage")) {
$header = "Tartaros merasa senang dengan kehadiranmu disini.<br/><a href=\"index.php?action=castle&amp;pilis=$j&amp;id=$id\">Castle</a>";
}
else{
$header = "Selamat datang di kerajaan Tartaros.<br/><a href=\"index.php?action=castle&amp;pilis=$j&amp;id=$id\">Castle</a>";}
?>

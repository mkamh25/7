<?php
$header = "Daerah ini selalu penuh dengan perampok.";
?>

<?php
$level_limit = 1;
if (($user['class'] == "ranger") or ($user['class'] == "druid")) {
$header = "Aura hijau selalu menyelimuti jiwamu.<br/><a href=\"index.php?action=castle&amp;pilis=$j&amp;id=$id\">Castle</a>";
}
else{
$header = "Selamat datang di kerajaan Enroth.<br/><a href=\"index.php?action=castle&amp;pilis=$j&amp;id=$id\">Castle</a>";}
?>

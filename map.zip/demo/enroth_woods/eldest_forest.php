<?php
$level_limit = 13;

$obj[0] = "martin_the_stranger";
$obj[1] = "dendroid_arches";

$unit[0] = "dendroid_guard";
$q_min[0] = 5;
$q_max[0] = 15;
$exp_min[0] = 3850;
$exp_max[0] = 5000;
$u_gold_min[0] = 2;
$u_gold_max[0] = 5;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "dendroid_soldier";
$q_min[1] = 6;
$q_max[1] = 12;
$exp_min[1] = 4450;
$exp_max[1] = 6500;
$u_gold_min[1] = 2;
$u_gold_max[1] = 7;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;
$army[0]="dendroid_guard";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="dendroid_soldier";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;

$gold_min = 6;
$gold_max = 11;
$gold_get = "7";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>
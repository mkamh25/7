<?php
$level_limit = 38;

$obj[0]="zdrag";
$obj[1] = "dragon_wood2";

$unit[0] = "green_dragon";
$q_min[0] = 10;
$q_max[0] = 25;
$exp_min[0] = 4850;
$exp_max[0] = 6000;
$u_gold_min[0] = 3;
$u_gold_max[0] = 4;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "dragonbone_greaves";
$u_artifact_get[0] = 400;

$unit[1] = "gold_dragon";
$q_min[1] = 6;
$q_max[1] = 28;
$exp_min[1] = 2450;
$exp_max[1] = 4000;
$u_gold_min[1] = 1;
$u_gold_max[1] = 3;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "dragon_wing_tabard";
$u_artifact_get[1] = 400;

$army[0]="gold_dragon";
$armi_min[0]=1;
$armi_max[0]=5;
$army_get[0]=25;
$army[1]="green_dragon";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;

$gold_min = 10;
$gold_max = 33;
$gold_get = "6";

$other = "crystal";
$other_min = 1;
$other_max = 3;
$other_get = 6;
?>

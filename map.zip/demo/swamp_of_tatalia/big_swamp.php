<?php
$level_limit = 38;
$obj[0] = "fly_tower2";


$unit[0] = "hydra";
$q_min[0] = 6;
$q_max[0] = 25;
$exp_min[0] = 1850;
$exp_max[0] = 4000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 10;
$u_gold_get[0] = 2;
$u_other[0] = "sulfur";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 8;
$u_artifact[0] = "sailor_potion";
$u_artifact_get[0] = 200;

$unit[1] = "chaos_hydra";
$q_min[1] = 7;
$q_max[1] = 20;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 8;
$u_gold_get[1] = 3;
$u_other[1] = "sulfur";
$u_other_min[1] = 1;
$u_other_max[1] = 2;
$u_other_get[1] = 10;
$u_artifact[1] = "glyph_of_gallantry";
$u_artifact_get[1] = 750;

$army[0]="hydra";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="chaos_hydra";
$armi_min[1]=1;
$armi_max[1]=5;
$army_get[1]=25;

$gold_min = 15;
$gold_max = 30;
$gold_get = "6";

$other = "sulfur";
$other_min = 1;
$other_max = 2;
$other_get = 10;
?>

<?php
$level_limit = 17;

$obj[0] = "wyvern_nest";
$obj[1] = "basilisk_pit2";


$unit[0] = "wyvern_monarch";
$q_min[0] = 3;
$q_max[0] = 9;
$exp_min[0] = 1850;
$exp_max[0] = 4000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 10;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "champions_milk";
$u_artifact_get[0] = 200;

$unit[1] = "mighty_gorgon";
$q_min[1] = 7;
$q_max[1] = 11;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 8;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "water";
$u_artifact_get[1] = 1000;

$unit[2] = "greater_basilisk";
$q_min[2] = 5;
$q_max[2] = 15;
$exp_min[2] = 4450;
$exp_max[2] = 5000;
$u_gold_min[2] = 3;
$u_gold_max[2] = 7;
$u_gold_get[2] = 6;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "scales_of_the_greater_basilisk";
$u_artifact_get[2] = 125;

$unit[3] = "wyvern";
$q_min[3] = 5;
$q_max[3] = 20;
$exp_min[3] = 6450;
$exp_max[3] = 8000;
$u_gold_min[3] = 1;
$u_gold_max[3] = 3;
$u_gold_get[3] = 5;
$u_other[3] = "";
$u_other_min[3] = 0;
$u_other_max[3] = 0;
$u_other_get[3] = 0;
$u_artifact[3] = "";
$u_artifact_get[3] = 0;
$army[0]="wyvern";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="mighty_gorgon";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;

$gold_min = 8;
$gold_max = 16;
$gold_get = "6";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

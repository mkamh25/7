<?php
$level_limit = 1;

$obj[0] = "ken_the_older";
$obj[1] = "lizard_den";
$obj[2] = "gnoll_hut";


$unit[0] = "gnoll";
$q_min[0] = 5;
$q_max[0] = 45;
$exp_min[0] = 1850;
$exp_max[0] = 5000;
$u_gold_min[0] = 2;
$u_gold_max[0] = 5;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "gnoll_marauder";
$q_min[1] = 7;
$q_max[1] = 40;
$exp_min[1] = 4450;
$exp_max[1] = 6500;
$u_gold_min[1] = 1;
$u_gold_max[1] = 6;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "rib_cage";
$u_artifact_get[1] = 100;

$army[0]="gnoll";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=10;

$army[1]="gnoll_marauder";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=10;


$gold_min = 3;
$gold_max = 4;
$gold_get = "8";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

<?php
$level_limit = 27;

$obj[0] = "kiler_kebot";
$obj[1] = "gorgon_lair2";
$obj[2] = "wyvern_nest2";

$unit[0] = "wyvern_monarch";
$q_min[0] = 5;
$q_max[0] = 12;
$exp_min[0] = 1850;
$exp_max[0] = 4000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 10;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "magic_potion";
$u_artifact_get[0] = 150;

$unit[1] = "mighty_gorgon";
$q_min[1] = 8;
$q_max[1] = 14;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 8;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "hydra";
$q_min[2] = 5;
$q_max[2] = 15;
$exp_min[2] = 4450;
$exp_max[2] = 5000;
$u_gold_min[2] = 3;
$u_gold_max[2] = 7;
$u_gold_get[2] = 6;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "greater_gnoll_flail";
$u_artifact_get[2] = 300;
$army[0]="mighty_gorgon";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=20;

$army[1]="wyvern_monarch";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=20;

$gold_min = 11;
$gold_max = 22;
$gold_get = "6";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

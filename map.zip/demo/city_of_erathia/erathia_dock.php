<?php
$level_limit = 6;

$obj[0] = "boro_the_tavernkeeper";
$obj[1] = "barracks";
$obj[2] = "griffin_tower2";

$unit[0] = "swordsman";
$q_min[0] = 5;
$q_max[0] = 15;
$exp_min[0] = 2850;
$exp_max[0] = 4000;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "magic_potion";
$u_artifact_get[0] = 150;

$unit[1] = "royal_griffin";
$q_min[1] = 8;
$q_max[1] = 28;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "endless_purse_of_gold";
$u_artifact_get[1] = 250;
$army[0]="swordsman";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=15;

$army[1]="royal_griffin";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=15;

$gold_min = 4;
$gold_max = 8;
$gold_get = "6";
$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

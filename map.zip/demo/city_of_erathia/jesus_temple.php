<?php
$level_limit = 50;

$obj[0]="jesus";
$obj[1]="popas";
$obj[2] = "portal_of_glory2";

$unit[0] = "angel";
$q_min[0] = 7;
$q_max[0] = 20;
$exp_min[0] = 6850;
$exp_max[0] = 18000;
$u_gold_min[0] = 15;
$u_gold_max[0] = 35;
$u_gold_get[0] = 2;
$u_other[0] = "gem";
$u_other_min[0] = 1;
$u_other_max[0] = 3;
$u_other_get[0] = 10;
$u_artifact[0] = "sandals_of_the_saint";
$u_artifact_get[0] = 500;

$unit[1] = "archangel";
$q_min[1] = 15;
$q_max[1] = 30;
$exp_min[1] = 8450;
$exp_max[1] = 24500;
$u_gold_min[1] = 25;
$u_gold_max[1] = 50;
$u_gold_get[1] = 2;
$u_other[1] = "gem";
$u_other_min[1] = 1;
$u_other_max[1] = 4;
$u_other_get[1] = 8;
$u_artifact[1] = "sentinel_shield";
$u_artifact_get[1] = 500;

$army[0]="angel";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="archangel";
$armi_min[1]=1;
$armi_max[1]=5;
$army_get[1]=25;


$gold_min = 30;
$gold_max = 50;
$gold_get = "3";

$other = "gem";
$other_min = 1;
$other_max = 3;
$other_get = 5;
?>

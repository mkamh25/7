<?php
$level_limit = 22;

$obj[0]="general_edric";
$obj[1] = "stable";
$obj[2] = "monastery2";
$obj[3]="workshop";

$unit[0] = "zealot";
$q_min[0] = 20;
$q_max[0] = 25;
$exp_min[0] = 5050;
$exp_max[0] = 7500;
$u_gold_min[0] = 1;
$u_gold_max[0] = 4;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "cavalier";
$q_min[1] = 10;
$q_max[1] = 20;
$exp_min[1] = 6000;
$exp_max[1] = 9000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 7;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "endless_sack_of_gold";
$u_artifact_get[1] = 250;

$unit[2] = "champion";
$q_min[2] = 20;
$q_max[2] = 25;
$exp_min[2] = 7000;
$exp_max[2] = 9000;
$u_gold_min[2] = 3;
$u_gold_max[2] = 7;
$u_gold_get[2] = 6;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;

$army[0]="champion";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=20;

$army[1]="cavalier";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=20;

$army[2]="zealot";
$armi_min[2]=1;
$armi_max[2]=10;
$army_get[2]=15;

$gold_min = 2;
$gold_max = 5;
$gold_get = "6";

$other = "gem";
$other_min = 1;
$other_max = 1;
$other_get = 10;
?>

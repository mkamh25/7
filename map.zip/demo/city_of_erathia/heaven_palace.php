<?php
$level_limit = 40;

$obj[0] = "portal_of_glory";
$obj[1] = "angel_agranel";

$unit[0] = "angel";
$q_min[0] = 5;
$q_max[0] = 15;
$exp_min[0] = 4850;
$exp_max[0] = 15000;
$u_gold_min[0] = 15;
$u_gold_max[0] = 35;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "angel_feather_arrows";
$u_artifact_get[0] = 300;

$unit[1] = "archangel";
$q_min[1] = 5;
$q_max[1] = 20;
$exp_min[1] = 4450;
$exp_max[1] = 18500;
$u_gold_min[1] = 25;
$u_gold_max[1] = 50;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "badge_of_courage";
$u_artifact_get[1] = 750;
$army[0]="angel";
$armi_min[0]=1;
$armi_max[0]=5;
$army_get[0]=20;


$gold_min = 10;
$gold_max = 20;
$gold_get = "3";

$other = "gem";
$other_min = 1;
$other_max = 3;
$other_get = 10;
?>

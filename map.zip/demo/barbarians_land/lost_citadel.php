<?php
$level_limit = 41;
$obj[0]="behemoth_lair2";

$unit[0] = "ancient_behemoth";
$q_min[0] = 5;
$q_max[0] = 25;
$exp_min[0] = 3850;
$exp_max[0] = 5000;
$u_gold_min[0] = 4;
$u_gold_max[0] = 5;
$u_gold_get[0] = 2;
$u_other[0] = "crystal";
$u_other_min[0] = 1;
$u_other_max[0] = 3;
$u_other_get[0] = 8;
$u_artifact[0] = "inst_barbarian_lords_axe_of_ferocity";
$u_artifact_get[0] = 600;

$unit[1] = "behemoth";
$q_min[1] = 5;
$q_max[1] = 25;
$exp_min[1] = 4450;
$exp_max[1] = 6500;
$u_gold_min[1] = 2;
$u_gold_max[1] = 8;
$u_gold_get[1] = 2;
$u_other[1] = "crystal";
$u_other_min[1] = 1;
$u_other_max[1] = 3;
$u_other_get[1] = 8;
$u_artifact[1] = "magic_potion";
$u_artifact_get[1] = 150;

$unit[2] = "cyclop_king";
$q_min[2] = 15;
$q_max[2] = 30;
$exp_min[2] = 4450;
$exp_max[2] = 6500;
$u_gold_min[2] = 2;
$u_gold_max[2] = 8;
$u_gold_get[2] = 2;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;

$unit[3] = "thunderbird";
$q_min[3] = 15;
$q_max[3] = 30;
$exp_min[3] = 4450;
$exp_max[3] = 6500;
$u_gold_min[3] = 2;
$u_gold_max[3] = 8;
$u_gold_get[3] = 2;
$u_other[3] = "";
$u_other_min[3] = 0;
$u_other_max[3] = 0;
$u_other_get[3] = 0;
$u_artifact[3] = "thunder_helmet";
$u_artifact_get[3] = 350;

$army[0]="behemoth";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="ancient_behemoth";
$armi_min[1]=1;
$armi_max[1]=5;
$army_get[1]=25;

$army[2]="thunderbird";
$armi_min[2]=1;
$armi_max[2]=15;
$army_get[2]=15;

$gold_min = 25;
$gold_max = 40;
$gold_get = "7";

$other = "crystal";
$other_min = 1;
$other_max = 3;
$other_get = 6;
?>

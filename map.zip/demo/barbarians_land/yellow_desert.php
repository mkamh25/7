<?php
$level_limit = 3;

$obj[0] = "gray_the_traveller";
$obj[1] = "orc_tower";
$obj[2] = "goblin_barracks2";

$unit[0] = "orc";
$q_min[0] = 8;
$q_max[0] = 15;
$exp_min[0] = 3850;
$exp_max[0] = 6000;
$u_gold_min[0] = 3;
$u_gold_max[0] = 4;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "magic_potion";
$u_artifact_get[0] = 150;

$unit[1] = "wolf_raider";
$q_min[1] = 5;
$q_max[1] = 25;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 8;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "surcoat_of_counterpoise";
$u_artifact_get[1] = 200;

$army[0]="orc";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=10;

$army[1]="wolf_raider";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=10;

$gold_min = 1;
$gold_max = 3;
$gold_get = "4";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

<?php
$need="ice_key";
$level_limit = 60;

?>
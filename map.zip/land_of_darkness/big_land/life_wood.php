<?php
$need="air_key";
$level_limit = 47;

$obj[0] = "sargis";
$obj[1] = "gorynych_home";
$obj[2] = "dragon_vault3";

$unit[0] = "gorynych";
$q_min[0] = 20;
$q_max[0] = 100;
$exp_min[0] = 285099;
$exp_max[0] = 499009;
$u_gold_min[0] = 11;
$u_gold_max[0] = 20;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "wind";
$u_artifact_get[0] = 450;

$unit[1] = "blood_dragon";
$q_min[1] = 20;
$q_max[1] = 100;
$exp_min[1] = 209900;
$exp_max[1] = 500990;
$u_gold_min[1] = 11;
$u_gold_max[1] = 20;
$u_gold_get[1] = 3;
$u_other[1] = "mercury";
$u_other_min[1] = 1;
$u_other_max[1] = 5;
$u_other_get[1] = 10;
$u_artifact[1] = "armageddons_blade";
$u_artifact_get[1] = 275;

$army[0]="gorynych";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=30;
$army[1]="blood_dragon";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=50;
$gold_min = 30;
$gold_max = 70;
$gold_get = "5";
$other = "mercury";
$other_min = 1;
$other_max = 5;
$other_get = 10;
?>

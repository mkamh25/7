<?php
$need="ice_key";
$level_limit = 52;

$obj[0] = "altar_of_dead3";
$obj[1] = "devil_temple3";

$unit[0] = "hell_baron";
$q_min[0] = 50;
$q_max[0] = 220;
$exp_min[0] = 285099;
$exp_max[0] = 499009;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "mercury";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 10;
$u_artifact[0] = "sea_captains_hat";
$u_artifact_get[0] = 345;

$unit[1] = "sacred_phoenix";
$q_min[1] = 50;
$q_max[1] = 220;
$exp_min[1] = 209900;
$exp_max[1] = 500990;
$u_gold_min[1] = 2;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "mercury";
$u_other_min[1] = 1;
$u_other_max[1] = 1;
$u_other_get[1] = 10;
$u_artifact[1] = "inst_elexir_of_life";
$u_artifact_get[1] = 400;

$army[0]="hell_baron";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=50;
$army[1]="sacred_phoenix";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=50;
$gold_min = 40;
$gold_max = 90;
$gold_get = "5";

$other = "mercury";
$other_min = 1;
$other_max = 12;
$other_get = 10;
?>

<?php
$need="air_key";
$level_limit = 29;

$obj[0] = "runner";
$obj[1] = "earth_land";
$obj[2] = "air_land";

$unit[0] = "air_messenger";
$q_min[0] = 20;
$q_max[0] = 55;
$exp_min[0] = 285099;
$exp_max[0] = 499009;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "ring_of_wayfarer";
$u_artifact_get[0] = 250;

$unit[1] = "earth_messenger";
$q_min[1] = 20;
$q_max[1] = 45;
$exp_min[1] = 209900;
$exp_max[1] = 500990;
$u_gold_min[1] = 2;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "inexhaustable_cart_of_ore";
$u_artifact_get[1] = 280;

$army[0]="air_messenger";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=15;
$army[1]="earth_messenger";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=15;
$gold_min = 20;
$gold_max = 40;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

<?php
$need="ice_key";
$level_limit = 57;

$obj[0]="mel_king";
$obj[1] = "gamt";
$obj[2] = "fly_tower3";
$obj[3] = "dragon_wood3";

$unit[0] = "hell_hydra";
$q_min[0] = 129;
$q_max[0] = 180;
$exp_min[0] = 285099;
$exp_max[0] = 499009;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "sulfur";
$u_other_min[0] = 1;
$u_other_max[0] = 5;
$u_other_get[0] = 10;
$u_artifact[0] = "inst_titans_thunder";
$u_artifact_get[0] = 400;

$unit[1] = "diamond_dragon";
$q_min[1] = 100;
$q_max[1] = 220;
$exp_min[1] = 209900;
$exp_max[1] = 500990;
$u_gold_min[1] = 2;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "crystal";
$u_other_min[1] = 1;
$u_other_max[1] = 5;
$u_other_get[1] = 10;
$u_artifact[1] = "speculum";
$u_artifact_get[1] = 380;

$army[0]="hell_hydra";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=50;
$army[1]="diamond_dragon";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=50;
$gold_min = 9;
$gold_max = 12;
$gold_get = "5";

$other = "mercury";
$other_min = 1;
$other_max = 10;
$other_get = 3;
?>

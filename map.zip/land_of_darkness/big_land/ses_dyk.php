<?php
$need="fire_key";
$level_limit = 61;

$obj[0] = "behemoth_lair3";
$obj[1] = "rust_jail3";

$unit[0] = "darkness_dragon";
$q_min[0] = 80;
$q_max[0] = 200;
$exp_min[0] = 285099;
$exp_max[0] = 499009;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "sulfur";
$u_other_min[0] = 1;
$u_other_max[0] = 9;
$u_other_get[0] = 10;
$u_artifact[0] = "head_of_legion";
$u_artifact_get[0] = 380;

$unit[1] = "ghost_behemoth";
$q_min[1] = 60;
$q_max[1] = 150;
$exp_min[1] = 209900;
$exp_max[1] = 500990;
$u_gold_min[1] = 2;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "crystal";
$u_other_min[1] = 1;
$u_other_max[1] = 9;
$u_other_get[1] = 10;
$u_artifact[1] = "inst_ring_of_the_magi";
$u_artifact_get[1] = 400;

$army[0]="ghost_behemoth";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=50;
$army[1]="darkness_dragon";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=50;
$gold_min = 30;
$gold_max = 70;
$gold_get = "5";

$other = "mercury";
$other_min = 1;
$other_max = 15;
$other_get = 7;
?>

<?php
$need="dark_key";
$level_limit = 15;

?>
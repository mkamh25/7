<?php
$need="air_key";
$level_limit = 25;

?>
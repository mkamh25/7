<?php
$need="angel_wings";
$level_limit = 95;
$header="Ini adalah tempat akhir dari semua perjalanan";
?>

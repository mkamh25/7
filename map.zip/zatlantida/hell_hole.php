<?php
$need="demon_wings";
$level_limit = 92;

?>
<?php
$need="angel_wings";
$level_limit = 87;

?>
<?php
$need="demon_wings";
$level_limit = 94;

$obj[0] = "haunted_tower";
$obj[1] = "sepulcher";

$unit[0] = "archlich";
$q_min[0] = 3000;
$q_max[0] = 6000;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 5000;
$u_gold_max[0] = 12000;
$u_gold_get[0] = 2;
$u_other[0] = "mercury";
$u_other_min[0] = 40;
$u_other_max[0] = 60;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "death_messenger";
$q_min[1] = 2500;
$q_max[1] = 5000;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 7000;
$u_gold_max[1] = 15000;
$u_gold_get[1] = 3;
$u_other[1] = "mercury";
$u_other_min[1] = 45;
$u_other_max[1] = 65;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="arhlich";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="death_messenger";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 4000;
$gold_max = 6000;
$gold_get = "6";

$other = "mercury";
$other_min = 10;
$other_max = 16;
$other_get = 8;
?>
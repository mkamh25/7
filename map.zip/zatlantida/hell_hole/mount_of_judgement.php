<?php
$need="demon_wings";
$level_limit = 100;

$obj[0] = "brutus_the_archdevil";
$obj[1] = "temple_of_the_fallen";
$obj[2] = "altar_of_blood";

$unit[0] = "lucifer";
$q_min[0] = 5000;
$q_max[0] = 8000;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 5000;
$u_gold_max[0] = 12000;
$u_gold_get[0] = 2;
$u_other[0] = "mercury";
$u_other_min[0] = 70;
$u_other_max[0] = 110;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "fallen_angel";
$q_min[1] = 3000;
$q_max[1] = 7000;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 9000;
$u_gold_max[1] = 19000;
$u_gold_get[1] = 3;
$u_other[1] = "gem";
$u_other_min[1] = 70;
$u_other_max[1] = 100;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="lucifer";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="fallen_angel";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 20000;
$gold_max = 30000;
$gold_get = "9";

$other = "gem";
$other_min = 16;
$other_max = 22;
$other_get = 8;
?>
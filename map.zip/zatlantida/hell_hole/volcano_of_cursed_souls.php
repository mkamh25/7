<?php
$need="demon_wings";
$level_limit = 95;

$obj[0] = "lava_fissure";

$unit[0] = "fire_dragon";
$q_min[0] = 2500;
$q_max[0] = 4200;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 5000;
$u_gold_max[0] = 12000;
$u_gold_get[0] = 2;
$u_other[0] = "sulfur";
$u_other_min[0] = 40;
$u_other_max[0] = 60;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "magma_dragon";
$q_min[1] = 2000;
$q_max[1] = 3500;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 7000;
$u_gold_max[1] = 15000;
$u_gold_get[1] = 3;
$u_other[1] = "sulfur";
$u_other_min[1] = 45;
$u_other_max[1] = 65;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="fire_dragon";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="magma_dragon";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 5000;
$gold_max = 9000;
$gold_get = "6";

$other = "sulfur";
$other_min = 11;
$other_max = 17;
$other_get = 8;
?>
<?php
$need="angel_wings";
$level_limit = 87;

$obj[0] = "clan_palace";
$obj[1] = "cathedral";

$unit[0] = "warlord";
$q_min[0] = 600;
$q_max[0] = 1100;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 200;
$u_gold_max[0] = 800;
$u_gold_get[0] = 2;
$u_other[0] = "gem";
$u_other_min[0] = 3;
$u_other_max[0] = 10;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "inquisitor";
$q_min[1] = 550;
$q_max[1] = 1300;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 300;
$u_gold_max[1] = 1000;
$u_gold_get[1] = 3;
$u_other[1] = "gem";
$u_other_min[1] = 4;
$u_other_max[1] = 12;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="warlord";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="inquisitor";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 100;
$gold_max = 300;
$gold_get = "6";

$other = "gem";
$other_min = 1;
$other_max = 7;
$other_get = 8;
?>
<?php
$need="angel_wings";
$level_limit = 89;

$obj[0] = "august_the_archangel";
$obj[1] = "dragon_altar";

$unit[0] = "sylvan_dragon";
$q_min[0] = 1200;
$q_max[0] = 2250;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 1000;
$u_gold_max[0] = 3000;
$u_gold_get[0] = 2;
$u_other[0] = "crystal";
$u_other_min[0] = 10;
$u_other_max[0] = 30;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "emerald_dragon";
$q_min[1] = 900;
$q_max[1] = 1800;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 2000;
$u_gold_max[1] = 5000;
$u_gold_get[1] = 3;
$u_other[1] = "crystal";
$u_other_min[1] = 15;
$u_other_max[1] = 30;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="sylvan_dragon";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="emerald_dragon";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 500;
$gold_max = 1200;
$gold_get = "6";

$other = "crystal";
$other_min = 3;
$other_max = 9;
$other_get = 8;
?>
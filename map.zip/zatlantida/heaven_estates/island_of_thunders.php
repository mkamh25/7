<?php
$need="angel_wings";
$level_limit = 90;

$obj[0] = "cloud_coliseum";

$unit[0] = "colossus";
$q_min[0] = 1500;
$q_max[0] = 3200;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 3000;
$u_gold_max[0] = 8000;
$u_gold_get[0] = 2;
$u_other[0] = "gem";
$u_other_min[0] = 20;
$u_other_max[0] = 48;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "power_titan";
$q_min[1] = 1000;
$q_max[1] = 2500;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 4000;
$u_gold_max[1] = 10000;
$u_gold_get[1] = 3;
$u_other[1] = "gem";
$u_other_min[1] = 25;
$u_other_max[1] = 50;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="colossus";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="power_titan";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 1000;
$gold_max = 2000;
$gold_get = "6";

$other = "gem";
$other_min = 4;
$other_max = 10;
$other_get = 8;
?>
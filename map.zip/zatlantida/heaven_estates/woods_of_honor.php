<?php
$need="angel_wings";
$level_limit = 88;

$obj[0] = "michael_the_archangel";
$obj[1] = "griffin_bastion";
$obj[2] = "pinnacle_of_wishes";

$unit[0] = "imperial_griffin";
$q_min[0] = 800;
$q_max[0] = 1500;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 400;
$u_gold_max[0] = 1200;
$u_gold_get[0] = 2;
$u_other[0] = "gem";
$u_other_min[0] = 5;
$u_other_max[0] = 15;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "rakshasa_raja";
$q_min[1] = 700;
$q_max[1] = 1400;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 500;
$u_gold_max[1] = 1400;
$u_gold_get[1] = 3;
$u_other[1] = "gem";
$u_other_min[1] = 6;
$u_other_max[1] = 18;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="imperial_griffin";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="rakshasa_raja";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 200;
$gold_max = 700;
$gold_get = "6";

$other = "gem";
$other_min = 2;
$other_max = 8;
$other_get = 8;
?>
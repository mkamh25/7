<?php
$need="angel_wings";
$level_limit = 94;

$obj[0] = "dragon_shrine";

$unit[0] = "emerald_dragon";
$q_min[0] = 2500;
$q_max[0] = 4500;
$exp_min[0] = 3850999999;
$exp_max[0] = 60009999999;
$u_gold_min[0] = 5000;
$u_gold_max[0] = 12000;
$u_gold_get[0] = 2;
$u_other[0] = "crystal";
$u_other_min[0] = 30;
$u_other_max[0] = 60;
$u_other_get[0] = 9;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "michael";
$q_min[1] = 2000;
$q_max[1] = 4000;
$exp_min[1] = 6450333333;
$exp_max[1] = 80003333333;
$u_gold_min[1] = 7000;
$u_gold_max[1] = 15000;
$u_gold_get[1] = 3;
$u_other[1] = "gem";
$u_other_min[1] = 40;
$u_other_max[1] = 70;
$u_other_get[1] = 9;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "sylvan_dragon";
$q_min[2] = 3000;
$q_max[2] = 5400;
$exp_min[2] = 6450333333;
$exp_max[2] = 80003333333;
$u_gold_min[2] = 7000;
$u_gold_max[2] = 15000;
$u_gold_get[2] = 3;
$u_other[2] = "crystal";
$u_other_min[2] = 40;
$u_other_max[2] = 70;
$u_other_get[2] = 9;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;

$army[0]="emerald_dragon";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=30;

$army[1]="michael";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=35;

$gold_min = 2000;
$gold_max = 4000;
$gold_get = "6";

$other = "gem";
$other_min = 6;
$other_max = 12;
$other_get = 8;
?>
<?php
$level_limit = 12;

$obj[0] = "tomb_of_souls2";
$obj[1] = "graveyard2";
$unit[0] = "zombie";
$q_min[0] = 20;
$q_max[0] = 40;
$exp_min[0] = 3450;
$exp_max[0] = 8500;
$u_gold_min[0] = 1;
$u_gold_max[0] = 6;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "dead_mans_boots";
$u_artifact_get[0] = 300;

$unit[1] = "wraith";
$q_min[1] = 5;
$q_max[1] = 25;
$exp_min[1] = 2850;
$exp_max[1] = 3000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "magic_potion";
$u_artifact_get[1] = 25;


$army[0]="wraith";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=15;

$army[1]="zombie";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=15;

$gold_min = 9;
$gold_max = 13;
$gold_get = "8";
$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

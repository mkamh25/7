<?php
$level_limit = 33;

$obj[0]="dk_orion";
$obj[1]="dark_stable2";

$unit[0] = "bone_dragon";
$q_min[0] = 5;
$q_max[0] = 20;
$exp_min[0] = 2850;
$exp_max[0] = 8000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 9;
$u_gold_get[0] = 2;
$u_other[0] = "mercury";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 12;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "black_knight";
$q_min[1] = 10;
$q_max[1] = 25;
$exp_min[1] = 4450;
$exp_max[1] = 5000;
$u_gold_min[1] = 4;
$u_gold_max[1] = 7;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "dread_knight";
$q_min[2] = 15;
$q_max[2] = 25;
$exp_min[2] = 4450;
$exp_max[2] = 5000;
$u_gold_min[2] = 4;
$u_gold_max[2] = 7;
$u_gold_get[2] = 2;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "inst_cloak_of_the_undead_king";
$u_artifact_get[2] = 5000;

$army[0]="dread_knight";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=25;

$army[1]="black_knight";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=20;

$gold_min = 15;
$gold_max = 30;
$gold_get = "4";

$other = "mercury";
$other_min = 1;
$other_max = 2;
$other_get = 9;
?>

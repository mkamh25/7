<?php
$level_limit = 37;
$obj[0]="dragon_vault2";

$unit[0] = "bone_dragon";
$q_min[0] = 5;
$q_max[0] = 20;
$exp_min[0] = 2850;
$exp_max[0] = 8000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 9;
$u_gold_get[0] = 2;
$u_other[0] = "mercury";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 12;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "ghost_dragon";
$q_min[1] = 1;
$q_max[1] = 15;
$exp_min[1] = 3000;
$exp_max[1] = 8500;
$u_gold_min[1] = 4;
$u_gold_max[1] = 7;
$u_gold_get[1] = 2;
$u_other[1] = "mercury";
$u_other_min[1] = 1;
$u_other_max[1] = 2;
$u_other_get[1] = 12;
$u_artifact[1] = "drago_scale_shield";
$u_artifact_get[1] = 275;

$unit[2] = "power_lich";
$q_min[2] = 9;
$q_max[2] = 30;
$exp_min[2] = 3450;
$exp_max[2] = 5000;
$u_gold_min[2] = 5;
$u_gold_max[2] = 7;
$u_gold_get[2] = 3;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;

$army[0]="power_lich";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=15;

$army[1]="bone_dragon";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;

$army[2]="ghost_dragon";
$armi_min[2]=1;
$armi_max[2]=5;
$army_get[2]=25;

$gold_min = 20;
$gold_max = 40;
$gold_get = "4";

$other = "mercury";
$other_min = 1;
$other_max = 3;
$other_get = 7;
?>

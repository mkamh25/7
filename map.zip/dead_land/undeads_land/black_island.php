<?php
$level_limit = 30;

$obj[0] = "dragon_vault";

$unit[0] = "bone_dragon";
$q_min[0] = 5;
$q_max[0] = 15;
$exp_min[0] = 2850;
$exp_max[0] = 8000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 9;
$u_gold_get[0] = 2;
$u_other[0] = "mercury";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 12;
$u_artifact[0] = "shield_of_the_yawnin_dead";
$u_artifact_get[0] = 200;

$unit[1] = "lich";
$q_min[1] = 6;
$q_max[1] = 48;
$exp_min[1] = 4450;
$exp_max[1] = 5000;
$u_gold_min[1] = 4;
$u_gold_max[1] = 7;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "everpouring_vidal_of_mercury";
$u_artifact_get[1] = 190;

$army[0]="lich";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=15;

$gold_min = 13;
$gold_max = 26;
$gold_get = "4";

$other = "mercury";
$other_min = 1;
$other_max = 1;
$other_get = 10;
?>

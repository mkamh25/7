<?php
$level_limit = 1;

$obj[0] = "clavius_the_zombie";
$obj[1] = "graveyard";

$unit[0] = "walking_dead";
$q_min[0] = 15;
$q_max[0] = 25;
$exp_min[0] = 1850;
$exp_max[0] = 4000;
$u_gold_min[0] = 2;
$u_gold_max[0] = 3;
$u_gold_get[0] = 5;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[1] = "skeleton";
$q_min[1] = 25;
$q_max[1] = 50;
$exp_min[1] = 4450;
$exp_max[1] = 5000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 5;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="skeleton";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=10;

$army[1]="walking_dead";
$armi_min[1]=1;
$armi_max[1]=12;
$army_get[1]=15;

$gold_min = 2;
$gold_max = 4;
$gold_get = "7";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>
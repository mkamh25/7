<?php
$level_limit = 10;

$obj[0] = "estate";
$obj[1] = "cursed_temple2";

$unit[0] = "skeleton_warrior";
$q_min[0] = 30;
$q_max[0] = 55;
$exp_min[0] = 3450;
$exp_max[0] = 5000;
$u_gold_min[0] = 3;
$u_gold_max[0] = 4;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "skull_helmet";
$u_artifact_get[0] = 100;
$unit[1] = "vampire";
$q_min[1] = 8;
$q_max[1] = 20;
$exp_min[1] = 2850;
$exp_max[1] = 4000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 8;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "wight";
$q_min[2] = 12;
$q_max[2] = 20;
$exp_min[2] = 2450;
$exp_max[2] = 4000;
$u_gold_min[2] = 3;
$u_gold_max[2] = 5;
$u_gold_get[2] = 4;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;
$army[0]="wight";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=15;

$gold_min = 3;
$gold_max = 6;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

<?php
$pilis=dungeon_caves;
$level_limit = 1;
if (($user['class'] == "overlord") or ($user['class'] == "warlock")) {
   $header = "Daerah yang sunyi, terbengkalai, dalam, dan goa-goa misterius adalah tempat tinggalmu.";
}
else{
$header = "Selamat datang di kerajaan Nighon.";}
?>
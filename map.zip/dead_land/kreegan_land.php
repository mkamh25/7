<?php
$pilis=kreegan_land;
$level_limit = 1;
if (($user['class'] == "demoniac") or ($user['class'] == "heretic")) {
   $header = "Dengan memasuki daerah kelahiran mu, raja kreegan yakin kekuatan mu akan bertambah.";
}
else{
$header = "Selamat datang di kerajaan Kreegan.";}
?>
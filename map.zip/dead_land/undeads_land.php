<?php
$pilis=undeads_land;
$level_limit = 3;
if (($user['class'] == "necromancer") or ($user['class'] == "death_knight")) {
   $header = "Selamat datang tuan, raja jadame telah menunggumu.";
}
else{
$header = "Selamat datang di kerajaan Jadame.";}
?>
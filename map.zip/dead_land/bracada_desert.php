<?php
$pilis=bracada_desert;
$level_limit = 2;
if (($user['class'] == "wizard") or ($user['class'] == "alchemist")) {
   $header = "Apa kau merasakan dengan adanya kau disini kekuatan mu bertambah?";
}
else{
$header = "Selamat datang di kerajaan Bracada.";}
?>



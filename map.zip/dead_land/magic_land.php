<?php
$pilis=magic_land;
$level_limit = 2;
if (($user['class'] == "planeswalker") or ($user['class'] == "elementalist")) {
   $header = "Selamat datang di tanah kelahiran mu.";
}
else{
$header = "Selamat datang di kerajaan Conflux.";}
?>
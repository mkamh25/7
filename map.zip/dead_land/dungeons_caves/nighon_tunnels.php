<?php
$level_limit = 6;

$obj[0] = "jeddite_the_warlock";
$obj[1] = "harpy_loft";

$unit[0] = "harpy";
$q_min[0] = 12;
$q_max[0] = 25;
$exp_min[0] = 6450;
$exp_max[0] = 8000;
$u_gold_min[0] = 3;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "armor_of_wonder";
$u_artifact_get[0] = 10;
$army[0]="beholder";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=15;

$army[1]="harpy";
$armi_min[1]=1;
$armi_max[1]=30;
$army_get[1]=15;

$gold_min = 1;
$gold_max = 3;
$gold_get = "3";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

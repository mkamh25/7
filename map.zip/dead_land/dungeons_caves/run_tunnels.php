<?php
$level_limit = 14;

$obj[0] = "labirint";
$obj[1] = "harpy_loft2";

$unit[0] = "harpy_hag";
$q_min[0] = 30;
$q_max[0] = 40;
$exp_min[0] = 3850;
$exp_max[0] = 6000;
$u_gold_min[0] = 3;
$u_gold_max[0] = 4;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "magica_potion";
$u_artifact_get[0] = 50;

$unit[1] = "minotaur";
$q_min[1] = 7;
$q_max[1] = 15;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 8;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "minotaur_king";
$q_min[2] = 7;
$q_max[2] = 15;
$exp_min[2] = 6450;
$exp_max[2] = 8000;
$u_gold_min[2] = 3;
$u_gold_max[2] = 8;
$u_gold_get[2] = 3;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;

$unit[3] = "medusa_queen";
$q_min[3] = 20;
$q_max[3] = 30;
$exp_min[3] = 6450;
$exp_max[3] = 8000;
$u_gold_min[3] = 3;
$u_gold_max[3] = 8;
$u_gold_get[3] = 3;
$u_other[3] = "";
$u_other_min[3] = 0;
$u_other_max[3] = 0;
$u_other_get[3] = 0;
$u_artifact[3] = "magic_potion";
$u_artifact_get[3] = 50;
$army[0]="harpy_hag";
$armi_min[0]=1;
$armi_max[0]=30;
$army_get[0]=10;

$army[1]="minotaur_king";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;

$army[2]="medusa_queen";
$armi_min[2]=1;
$armi_max[2]=20;
$army_get[2]=15;

$gold_min = 8;
$gold_max = 11;
$gold_get = "3";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>
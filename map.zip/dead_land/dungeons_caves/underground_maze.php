<?php
$level_limit = 11;

$obj[0] = "sulfurs_market";
$obj[1] = "chapel_of_stilled_voices";
$obj[2]="pillar_of_eyes2";

$unit[0] = "medusa";
$q_min[0] = 8;
$q_max[0] = 25;
$exp_min[0] = 4850;
$exp_max[0] = 6500;
$u_gold_min[0] = 4;
$u_gold_max[0] = 7;
$u_gold_get[0] = 2;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "eversmoking_ring_of_sulfur";
$u_artifact_get[0] = 200;

$unit[1] = "evil_eye";
$q_min[1] = 10;
$q_max[1] = 35;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 8;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="medusa";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=15;

$army[1]="evil_eye";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=20;

$gold_min = 5;
$gold_max = 10;
$gold_get = "4";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

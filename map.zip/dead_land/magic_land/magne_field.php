<?php
$level_limit = 30;

$obj[0] = "altar_of_dead";
$obj[1] = "magic_temple2";

$unit[0] = "magic_elemental";
$q_min[0] = 25;
$q_max[0] = 50;
$exp_min[0] = 2000;
$exp_max[0] = 3500;
$u_gold_min[0] = 2;
$u_gold_max[0] = 3;
$u_gold_get[0] = 5;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "mystic_orb_of_mana";
$u_artifact_get[0] = 200;

$unit[1] = "firebird";
$q_min[1] = 15;
$q_max[1] = 25;
$exp_min[1] = 39000;
$exp_max[1] = 49000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 3;
$u_gold_get[1] = 5;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "ladybird_of_luck";
$u_artifact_get[1] = 180;

$army[0]="magic_elemental";
$armi_min[0]=1;
$armi_max[0]=12;
$army_get[0]=25;

$army[1]="firebird";
$armi_min[1]=1;
$armi_max[1]=8;
$army_get[1]=30;

$gold_min = 7;
$gold_max = 11;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

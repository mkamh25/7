<?php
$level_limit = 21;

$obj[0] = "earth_temple2";

$unit[0] = "magma_elemental";
$q_min[0] = 25;
$q_max[0] = 55;
$exp_min[0] = 25000;
$exp_max[0] = 35500;
$u_gold_min[0] = 2;
$u_gold_max[0] = 3;
$u_gold_get[0] = 5;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "magic_potion";
$u_artifact_get[0] = 50;

$unit[1] = "psychic_elemental";
$q_min[1] = 20;
$q_max[1] = 45;
$exp_min[1] = 30050;
$exp_max[1] = 45000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 3;
$u_gold_get[1] = 5;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "charm_of_mana";
$u_artifact_get[1] = 200;

$army[0]="magma_elemental";
$armi_min[0]=1;
$armi_max[0]=15;
$army_get[0]=25;

$army[1]="psychic_elemental";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=25;

$gold_min = 3;
$gold_max = 6;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

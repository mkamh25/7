<?php
$level_limit = 9;

$obj[0] = "fire_temple";
$obj[1] = "air_temple2";


$unit[0] = "storm_elemental";
$q_min[0] = 25;
$q_max[0] = 35;
$exp_min[0] = 2000;
$exp_max[0] = 3500;
$u_gold_min[0] = 2;
$u_gold_max[0] = 3;
$u_gold_get[0] = 5;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "pendant_of_second_sight";
$u_artifact_get[0] = 180;

$unit[1] = "fire_elemental";
$q_min[1] = 20;
$q_max[1] = 30;
$exp_min[1] = 3000;
$exp_max[1] = 4000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 3;
$u_gold_get[1] = 5;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "magic_potion";
$u_artifact_get[1] = 50;
$army[0]="storm_elemental";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=20;

$army[1]="fire_elemental";
$armi_min[1]=1;
$armi_max[1]=15;
$army_get[1]=20;

$gold_min = 3;
$gold_max = 6;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

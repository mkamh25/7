<?php
$level_limit = 37;

$obj[0]="cold_fenix";
$obj[1] = "altar_of_dead2";


$unit[0] = "firebird";
$q_min[0] = 25;
$q_max[0] = 40;
$exp_min[0] = 20900;
$exp_max[0] = 35900;
$u_gold_min[0] = 2;
$u_gold_max[0] = 3;
$u_gold_get[0] = 5;
$u_other[0] = "mercury";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 15;
$u_artifact[0] = "cards_of_prophecy";
$u_artifact_get[0] = 180;

$unit[1] = "phoenix";
$q_min[1] = 15;
$q_max[1] = 35;
$exp_min[1] = 39000;
$exp_max[1] = 49000;
$u_gold_min[1] = 2;
$u_gold_max[1] = 3;
$u_gold_get[1] = 5;
$u_other[1] = "mercury";
$u_other_min[1] = 1;
$u_other_max[1] = 2;
$u_other_get[1] = 10;
$u_artifact[1] = "crest_of_valor";
$u_artifact_get[1] = 250;

$army[0]="firebird";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="phoenix";
$armi_min[1]=1;
$armi_max[1]=5;
$army_get[1]=25;

$gold_min = 21;
$gold_max = 30;
$gold_get = "5";

$other = "mercury";
$other_min = 1;
$other_max = 3;
$other_get = 8;
?>

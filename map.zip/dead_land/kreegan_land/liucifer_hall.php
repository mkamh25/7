<?php
$level_limit = 35;
$obj[0] = "liucifer";
$obj[1] = "devil_temple";
$unit[0] = "efreet_sultan";
$q_min[0] = 15;
$q_max[0] = 30;
$exp_min[0] = 2850;
$exp_max[0] = 4000;
$u_gold_min[0] = 2;
$u_gold_max[0] = 5;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "sailor_potion";
$u_artifact_get[0] = 80;

$unit[1] = "devil";
$q_min[1] = 15;
$q_max[1] = 25;
$exp_min[1] = 4450;
$exp_max[1] = 8500;
$u_gold_min[1] = 3;
$u_gold_max[1] = 6;
$u_gold_get[1] = 2;
$u_other[1] = "mercury";
$u_other_min[1] = 1;
$u_other_max[1] = 1;
$u_other_get[1] = 6;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "archdevil";
$q_min[2] = 10;
$q_max[2] = 25;
$exp_min[2] = 4450;
$exp_max[2] = 5000;
$u_gold_min[2] = 2;
$u_gold_max[2] = 5;
$u_gold_get[2] = 5;
$u_other[2] = "mercury";
$u_other_min[2] = 1;
$u_other_max[2] = 2;
$u_other_get[2] = 7;
$u_artifact[2] = "sword_of_hellfire";
$u_artifact_get[2] = 210;
$unit[3] = "pit_lord";
$q_min[3] = 10;
$q_max[3] = 20;
$exp_min[3] = 4450;
$exp_max[3] = 6000;
$u_gold_min[3] = 1;
$u_gold_max[3] = 2;
$u_gold_get[3] = 2;
$u_other[3] = "";
$u_other_min[3] = 0;
$u_other_max[3] = 0;
$u_other_get[3] = 0;
$u_artifact[3] = "";
$u_artifact_get[3] = 0;
$army[0]="devil";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="efreet_sultan";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=15;


$gold_min = 13;
$gold_max = 26;
$gold_get = "4";

$other = "mercury";
$other_min = 1;
$other_max = 1;
$other_get = 8;
?>

<?php
if (($user['class'] == "demoniac") or ($user['class'] == "heretic")) {
$level_limit = 24;}
else{
$level_limit = 29;}

$obj[0]="fire_lake2";
$obj[1]="hell_hole2";

$unit[0] = "efreet_sultan";
$q_min[0] = 5;
$q_max[0] = 15;
$exp_min[0] = 2850;
$exp_max[0] = 4000;
$u_gold_min[0] = 2;
$u_gold_max[0] = 5;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "hellstorm_helmet";
$u_artifact_get[0] = 155;

$unit[1] = "pit_lord";
$q_min[1] = 20;
$q_max[1] = 25;
$exp_min[1] = 4450;
$exp_max[1] = 6000;
$u_gold_min[1] = 1;
$u_gold_max[1] = 2;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="pit_lord";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$army[1]="efreet_sultan";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;
$gold_min = 4;
$gold_max = 5;
$gold_get = "4";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

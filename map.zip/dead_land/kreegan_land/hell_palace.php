<?php
if (($user['class'] == "demoniac") or ($user['class'] == "heretic")) {
$level_limit = 18;}
else{
$level_limit = 24;}

$obj[0] = "ossy_the_beast";
$obj[1] = "stones_market";
$obj[2] = "fire_lake";
$obj[3] = "hell_hole";

$unit[0] = "efreet";
$q_min[0] = 7;
$q_max[0] = 15;
$exp_min[0] = 4850;
$exp_max[0] = 6000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 10;
$u_gold_get[0] = 2;
$u_other[0] = "mercury";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 10;
$u_artifact[0] = "";
$u_artifact_get[0] = 0;

$unit[2] = "pit_fiend";
$q_min[2] = 15;
$q_max[2] = 20;
$exp_min[2] = 6450;
$exp_max[2] = 8000;
$u_gold_min[2] = 4;
$u_gold_max[2] = 6;
$u_gold_get[2] = 2;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "recanters_cloak";
$u_artifact_get[2] = 170;

$unit[1] = "pit_lord";
$q_min[1] = 10;
$q_max[1] = 15;
$exp_min[1] = 6450;
$exp_max[1] = 8000;
$u_gold_min[1] = 4;
$u_gold_max[1] = 6;
$u_gold_get[1] = 2;
$u_other[1] = "stone";
$u_other_min[1] = 1;
$u_other_max[1] = 1;
$u_other_get[1] = 20;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;
$army[0]="pit_fiend";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=15;

$army[1]="efreet";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;


$gold_min = 12;
$gold_max = 15;
$gold_get = "4";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

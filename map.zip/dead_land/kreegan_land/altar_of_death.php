<?php

$level_limit = 22;

$unit[0] = "reckless";
$q_min[0] = 15;
$q_max[0] = 30;
$exp_min[0] = 6000;
$exp_max[0] = 7900;
$u_gold_min[0] = 2;
$u_gold_max[0] = 5;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "dark_key";
$u_artifact_get[0] = 150;

$unit[1] = "pit_fiend";
$q_min[1] = 15;
$q_max[1] = 20;
$exp_min[1] = 3459;
$exp_max[1] = 5509;
$u_gold_min[1] = 3;
$u_gold_max[1] = 6;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$army[0]="pit_fiend";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=35;

$gold_min = 4;
$gold_max = 5;
$gold_get = "4";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

<?php
$level_limit = 35;

$obj[0] = "poll_the_warrior";
$obj[1] = "cloud_temple";
$obj[2]="golem_factory4";

$unit[0] = "giant";
$q_min[0] = 1;
$q_max[0] = 6;
$exp_min[0] = 550;
$exp_max[0] = 2600;
$u_gold_min[0] = 4;
$u_gold_max[0] = 8;
$u_gold_get[0] = 4;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "titan_cuiras";
$u_artifact_get[0] = 190;

$unit[1] = "diamond_golem";
$q_min[1] = 6;
$q_max[1] = 25;
$exp_min[1] = 2450;
$exp_max[1] = 5500;
$u_gold_min[1] = 2;
$u_gold_max[1] = 8;
$u_gold_get[1] = 4;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "stone_golem";
$q_min[2] = 10;
$q_max[2] = 30;
$exp_min[2] = 4450;
$exp_max[2] = 6000;
$u_gold_min[2] = 2;
$u_gold_max[2] = 5;
$u_gold_get[2] = 6;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;
$army[0]="diamond_golem";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=25;

$army[1]="stone_golem";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=20;

$gold_min = 10;
$gold_max = 20;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

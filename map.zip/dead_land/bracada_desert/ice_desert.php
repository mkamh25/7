<?php
$level_limit = 17;

$obj[0] = "altar_of_wishes";

$unit[0] = "naga";
$q_min[0] = 3;
$q_max[0] = 8;
$exp_min[0] = 1850;
$exp_max[0] = 4000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 8;
$u_gold_get[0] = 3;
$u_other[0] = "gem";
$u_other_min[0] = 1;
$u_other_max[0] = 1;
$u_other_get[0] = 10;
$u_artifact[0] = "orb_of_driving_rain";
$u_artifact_get[0] = 500;

$unit[1] = "gold_golem";
$q_min[1] = 5;
$q_max[1] = 25;
$exp_min[1] = 2450;
$exp_max[1] = 4500;
$u_gold_min[1] = 5;
$u_gold_max[1] = 10;
$u_gold_get[1] = 3;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "";
$u_artifact_get[1] = 0;

$unit[2] = "genie";
$q_min[2] = 8;
$q_max[2] = 25;
$exp_min[2] = 1450;
$exp_max[2] = 3500;
$u_gold_min[2] = 3;
$u_gold_max[2] = 5;
$u_gold_get[2] = 4;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "ring_of_conjuring";
$u_artifact_get[2] = 120;
$army[0]="naga";
$armi_min[0]=1;
$armi_max[0]=10;
$army_get[0]=20;

$gold_min = 7;
$gold_max = 14;
$gold_get = "4";

$other = "gem";
$other_min = 1;
$other_max = 1;
$other_get = 10;
?>
<?php
$level_limit = 28;

$obj[0]="mag_tower2";
$obj[1]="altar_of_wishes2";

$unit[0] = "arch_magi";
$q_min[0] = 8;
$q_max[0] = 34;
$exp_min[0] = 3850;
$exp_max[0] = 6000;
$u_gold_min[0] = 5;
$u_gold_max[0] = 10;
$u_gold_get[0] = 3;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "cape_of_conjuring";
$u_artifact_get[0] = 200;

$unit[1] = "enchanter";
$q_min[1] = 15;
$q_max[1] = 30;
$exp_min[1] = 3450;
$exp_max[1] = 8000;
$u_gold_min[1] = 4;
$u_gold_max[1] = 9;
$u_gold_get[1] = 2;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "ambassadors_sash";
$u_artifact_get[1] = 210;

$unit[2] = "genie";
$q_min[2] = 15;
$q_max[2] = 30;
$exp_min[2] = 3850;
$exp_max[2] = 6000;
$u_gold_min[2] = 5;
$u_gold_max[2] = 10;
$u_gold_get[2] = 3;
$u_other[2] = "";
$u_other_min[2] = 0;
$u_other_max[2] = 0;
$u_other_get[2] = 0;
$u_artifact[2] = "";
$u_artifact_get[2] = 0;
$unit[3] = "master_genie";
$q_min[3] = 5;
$q_max[3] = 16;
$exp_min[3] = 2450;
$exp_max[3] = 7000;
$u_gold_min[3] = 4;
$u_gold_max[3] = 8;
$u_gold_get[3] = 4;
$u_other[3] = "";
$u_other_min[3] = 0;
$u_other_max[3] = 0;
$u_other_get[3] = 0;
$u_artifact[3] = "crown_of_the_supreme_magi";
$u_artifact_get[3] = 400;

$army[0]="arch_magi";
$armi_min[0]=1;
$armi_max[0]=20;
$army_get[0]=20;

$army[1]="master_genie";
$armi_min[1]=1;
$armi_max[1]=10;
$army_get[1]=20;

$army[2]="genie";
$armi_min[2]=1;
$armi_max[2]=10;
$army_get[2]=20;

$gold_min = 8;
$gold_max = 16;
$gold_get = "4";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

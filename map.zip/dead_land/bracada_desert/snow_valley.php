<?php
$level_limit = 1;

$obj[0] = "torre_the_merchant";
$obj[1] = "parapet";
$obj[2]="gremlin_h";

$unit[0] = "stone_gargoyle";
$q_min[0] = 18;
$q_max[0] = 30;
$exp_min[0] = 2850;
$exp_max[0] = 4000;
$u_gold_min[0] = 3;
$u_gold_max[0] = 5;
$u_gold_get[0] = 6;
$u_other[0] = "";
$u_other_min[0] = 0;
$u_other_max[0] = 0;
$u_other_get[0] = 0;
$u_artifact[0] = "orb_of_firmament";
$u_artifact_get[0] = 200;

$unit[1] = "gremlin";
$q_min[1] = 50;
$q_max[1] = 85;
$exp_min[1] = 6450;
$exp_max[1] = 10000;
$u_gold_min[1] = 3;
$u_gold_max[1] = 7;
$u_gold_get[1] = 4;
$u_other[1] = "";
$u_other_min[1] = 0;
$u_other_max[1] = 0;
$u_other_get[1] = 0;
$u_artifact[1] = "magic_potion";
$u_artifact_get[1] = 50;

$army[0]="stone_gargoyle";
$armi_min[0]=1;
$armi_max[0]=12;
$army_get[0]=15;

$army[1]="gremlin";
$armi_min[1]=1;
$armi_max[1]=20;
$army_get[1]=10;

$gold_min = 3;
$gold_max = 5;
$gold_get = "5";

$other = "";
$other_min = 0;
$other_max = 0;
$other_get = 0;
?>

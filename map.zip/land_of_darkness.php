<?php
$need="dark_key";
$header="Selamat datang di wilayah kegelapan";
?>
